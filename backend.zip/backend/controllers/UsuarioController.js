const Usuario = require('../models/Usuario');

// Criar novo usuário
exports.criar = async (req, res) => {
  try {
    const usuario = new Usuario(req.body);
    await usuario.save();
    res.status(201).json({
      mensagem: 'Usuário cadastrado com sucesso',
      usuario: {
        id: usuario._id,
        nome: usuario.nome,
        tipo: usuario.tipo
      }
    });
  } catch (error) {
    res.status(400).json({
      erro: error.message || 'Erro ao cadastrar usuário'
    });
  }
};

// Listar todos os usuários (com filtros opcionais)
exports.listar = async (req, res) => {
  try {
    const { tipo, zona } = req.query;
    const filtro = {};
    
    if (tipo) filtro.tipo = tipo;
    if (zona) filtro.zona = zona;
    
    const usuarios = await Usuario.find(filtro)
      .select('-cpf -cnpj') // Não retorna dados sensíveis
      .sort('nome');
    
    res.json(usuarios);
  } catch (error) {
    res.status(500).json({
      erro: 'Erro ao listar usuários'
    });
  }
};

// Buscar usuário por ID
exports.buscarPorId = async (req, res) => {
  try {
    const usuario = await Usuario.findById(req.params.id)
      .select('-cpf -cnpj'); // Não retorna dados sensíveis
    
    if (!usuario) {
      return res.status(404).json({
        erro: 'Usuário não encontrado'
      });
    }
    
    res.json(usuario);
  } catch (error) {
    res.status(500).json({
      erro: 'Erro ao buscar usuário'
    });
  }
};

// Atualizar usuário
exports.atualizar = async (req, res) => {
  try {
    const usuario = await Usuario.findById(req.params.id);
    
    if (!usuario) {
      return res.status(404).json({
        erro: 'Usuário não encontrado'
      });
    }

    // Não permite alterar tipo de usuário
    delete req.body.tipo;
    
    // Atualiza os campos
    Object.keys(req.body).forEach(key => {
      usuario[key] = req.body[key];
    });
    
    await usuario.save();
    res.json({
      mensagem: 'Usuário atualizado com sucesso',
      usuario: {
        id: usuario._id,
        nome: usuario.nome,
        tipo: usuario.tipo
      }
    });
  } catch (error) {
    res.status(400).json({
      erro: error.message || 'Erro ao atualizar usuário'
    });
  }
};

// Desativar usuário
exports.desativar = async (req, res) => {
  try {
    const usuario = await Usuario.findById(req.params.id);
    
    if (!usuario) {
      return res.status(404).json({
        erro: 'Usuário não encontrado'
      });
    }
    
    usuario.ativo = false;
    await usuario.save();
    
    res.json({
      mensagem: 'Usuário desativado com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      erro: 'Erro ao desativar usuário'
    });
  }
};

// Buscar coletores por região
exports.buscarColetoresPorRegiao = async (req, res) => {
  try {
    const { zona } = req.params;
    const coletores = await Usuario.find({
      tipo: 'coletor',
      regiaoAtuacao: zona,
      ativo: true
    }).select('nome telefone tiposColeta disponibilidade');
    
    res.json(coletores);
  } catch (error) {
    res.status(500).json({
      erro: 'Erro ao buscar coletores'
    });
  }
};

// Buscar empresas por tipo de material
exports.buscarEmpresasPorMaterial = async (req, res) => {
  try {
    const { material } = req.params;
    const empresas = await Usuario.find({
      tipo: 'empresa',
      tiposMaterial: material,
      ativo: true
    }).select('nome endereco zona tiposMaterial');
    
    res.json(empresas);
  } catch (error) {
    res.status(500).json({
      erro: 'Erro ao buscar empresas'
    });
  }
};