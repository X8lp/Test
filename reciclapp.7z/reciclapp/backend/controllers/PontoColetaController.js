const PontoColeta = require('../models/PontoColeta');

// Criar novo ponto de coleta
exports.criar = async (req, res) => {
  try {
    const pontoColeta = new PontoColeta(req.body);
    await pontoColeta.save();
    res.status(201).json({
      mensagem: 'Ponto de coleta cadastrado com sucesso',
      pontoColeta: {
        id: pontoColeta._id,
        nome: pontoColeta.nome,
        endereco: pontoColeta.endereco
      }
    });
  } catch (error) {
    res.status(400).json({
      erro: error.message || 'Erro ao cadastrar ponto de coleta'
    });
  }
};

// Listar todos os pontos de coleta (com filtros opcionais)
exports.listar = async (req, res) => {
  try {
    const { zona, material, status } = req.query;
    const filtro = {};
    
    if (zona) filtro.zona = zona;
    if (material) filtro.tiposMaterial = material;
    if (status) filtro.status = status;
    else filtro.status = 'ativo'; // Por padrão, lista apenas ativos
    
    const pontosColeta = await PontoColeta.find(filtro)
      .populate('responsavel', 'nome telefone')
      .sort('nome');
    
    res.json(pontosColeta);
  } catch (error) {
    res.status(500).json({
      erro: 'Erro ao listar pontos de coleta'
    });
  }
};

// Buscar ponto de coleta por ID
exports.buscarPorId = async (req, res) => {
  try {
    const pontoColeta = await PontoColeta.findById(req.params.id)
      .populate('responsavel', 'nome telefone');
    
    if (!pontoColeta) {
      return res.status(404).json({
        erro: 'Ponto de coleta não encontrado'
      });
    }
    
    res.json(pontoColeta);
  } catch (error) {
    res.status(500).json({
      erro: 'Erro ao buscar ponto de coleta'
    });
  }
};

// Atualizar ponto de coleta
exports.atualizar = async (req, res) => {
  try {
    const pontoColeta = await PontoColeta.findById(req.params.id);
    
    if (!pontoColeta) {
      return res.status(404).json({
        erro: 'Ponto de coleta não encontrado'
      });
    }
    
    // Atualiza os campos
    Object.keys(req.body).forEach(key => {
      pontoColeta[key] = req.body[key];
    });
    
    await pontoColeta.save();
    res.json({
      mensagem: 'Ponto de coleta atualizado com sucesso',
      pontoColeta: {
        id: pontoColeta._id,
        nome: pontoColeta.nome,
        status: pontoColeta.status
      }
    });
  } catch (error) {
    res.status(400).json({
      erro: error.message || 'Erro ao atualizar ponto de coleta'
    });
  }
};

// Alterar status do ponto de coleta
exports.alterarStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const pontoColeta = await PontoColeta.findById(req.params.id);
    
    if (!pontoColeta) {
      return res.status(404).json({
        erro: 'Ponto de coleta não encontrado'
      });
    }
    
    pontoColeta.status = status;
    await pontoColeta.save();
    
    res.json({
      mensagem: 'Status do ponto de coleta atualizado com sucesso',
      status: status
    });
  } catch (error) {
    res.status(500).json({
      erro: 'Erro ao alterar status do ponto de coleta'
    });
  }
};

// Buscar pontos de coleta próximos
exports.buscarProximos = async (req, res) => {
  try {
    const { latitude, longitude, raio } = req.query;
    
    if (!latitude || !longitude) {
      return res.status(400).json({
        erro: 'Latitude e longitude são obrigatórios'
      });
    }
    
    const pontosProximos = await PontoColeta.buscarProximos(
      parseFloat(latitude),
      parseFloat(longitude),
      raio ? parseFloat(raio) : 5
    );
    
    res.json(pontosProximos);
  } catch (error) {
    res.status(500).json({
      erro: 'Erro ao buscar pontos de coleta próximos'
    });
  }
};

// Buscar pontos de coleta por tipo de material
exports.buscarPorMaterial = async (req, res) => {
  try {
    const { material } = req.params;
    const pontos = await PontoColeta.buscarPorMaterial(material);
    res.json(pontos);
  } catch (error) {
    res.status(500).json({
      erro: 'Erro ao buscar pontos de coleta por material'
    });
  }
};

// Buscar pontos de coleta por zona
exports.buscarPorZona = async (req, res) => {
  try {
    const { zona } = req.params;
    const pontos = await PontoColeta.buscarPorZona(zona);
    res.json(pontos);
  } catch (error) {
    res.status(500).json({
      erro: 'Erro ao buscar pontos de coleta por zona'
    });
  }
};