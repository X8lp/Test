const mongoose = require('mongoose');

const pontoColetaSchema = new mongoose.Schema({
  nome: {
    type: String,
    required: true
  },
  endereco: {
    type: String,
    required: true
  },
  numero: {
    type: String,
    required: true
  },
  bairro: {
    type: String,
    required: true
  },
  zona: {
    type: String,
    required: true,
    enum: ['norte', 'sul', 'leste', 'oeste', 'centro-sul', 'centro-oeste']
  },
  tiposMaterial: [{
    type: String,
    enum: ['papel', 'plastico', 'vidro', 'metal', 'eletronico'],
    required: true
  }],
  descricao: {
    type: String,
    required: true
  },
  horarioFuncionamento: {
    type: String,
    required: true
  },
  responsavel: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Usuario',
    required: true
  },
  coordenadas: {
    latitude: {
      type: Number,
      required: true
    },
    longitude: {
      type: Number,
      required: true
    }
  },
  status: {
    type: String,
    enum: ['ativo', 'inativo', 'em_manutencao'],
    default: 'ativo'
  },
  dataCadastro: {
    type: Date,
    default: Date.now
  },
  ultimaAtualizacao: {
    type: Date,
    default: Date.now
  }
});

// Índice geoespacial para buscas por proximidade
pontoColetaSchema.index({ coordenadas: '2dsphere' });

// Middleware para atualizar a data de última atualização
pontoColetaSchema.pre('save', function(next) {
  this.ultimaAtualizacao = new Date();
  next();
});

// Método estático para buscar pontos próximos
pontoColetaSchema.statics.buscarProximos = function(latitude, longitude, raioKm = 5) {
  return this.find({
    coordenadas: {
      $near: {
        $geometry: {
          type: 'Point',
          coordinates: [longitude, latitude]
        },
        $maxDistance: raioKm * 1000 // converte para metros
      }
    },
    status: 'ativo'
  });
};

// Método estático para buscar por tipo de material
pontoColetaSchema.statics.buscarPorMaterial = function(tipoMaterial) {
  return this.find({
    tiposMaterial: tipoMaterial,
    status: 'ativo'
  });
};

// Método estático para buscar por zona
pontoColetaSchema.statics.buscarPorZona = function(zona) {
  return this.find({
    zona: zona,
    status: 'ativo'
  });
};

module.exports = mongoose.model('PontoColeta', pontoColetaSchema);