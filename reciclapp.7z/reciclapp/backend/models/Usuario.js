const mongoose = require('mongoose');

const usuarioSchema = new mongoose.Schema({
  nome: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  telefone: {
    type: String,
    required: true
  },
  endereco: {
    type: String,
    required: true
  },
  numero: {
    type: String,
    required: true
  },
  bairro: {
    type: String,
    required: true
  },
  zona: {
    type: String,
    required: true,
    enum: ['norte', 'sul', 'leste', 'oeste', 'centro-sul', 'centro-oeste']
  },
  tipo: {
    type: String,
    required: true,
    enum: ['empresa', 'coletor', 'pessoa']
  },
  // Campos específicos para empresas
  cnpj: {
    type: String,
    sparse: true,
    unique: true
  },
  razaoSocial: String,
  tiposMaterial: [{
    type: String,
    enum: ['papel', 'plastico', 'vidro', 'metal', 'eletronico']
  }],
  descricaoEmpresa: String,
  // Campos específicos para coletores
  cpf: {
    type: String,
    sparse: true,
    unique: true
  },
  tiposColeta: [{
    type: String,
    enum: ['papel', 'plastico', 'vidro', 'metal', 'eletronico']
  }],
  regiaoAtuacao: [{
    type: String,
    enum: ['norte', 'sul', 'leste', 'oeste', 'centro-sul', 'centro-oeste']
  }],
  disponibilidade: String,
  // Campos de controle
  dataCadastro: {
    type: Date,
    default: Date.now
  },
  ativo: {
    type: Boolean,
    default: true
  }
});

// Middleware para validar campos específicos baseado no tipo
usuarioSchema.pre('save', function(next) {
  if (this.tipo === 'empresa') {
    if (!this.cnpj) {
      next(new Error('CNPJ é obrigatório para empresas'));
    }
    if (!this.tiposMaterial || this.tiposMaterial.length === 0) {
      next(new Error('Tipos de material são obrigatórios para empresas'));
    }
  } else if (this.tipo === 'coletor') {
    if (!this.cpf) {
      next(new Error('CPF é obrigatório para coletores'));
    }
    if (!this.tiposColeta || this.tiposColeta.length === 0) {
      next(new Error('Tipos de coleta são obrigatórios para coletores'));
    }
    if (!this.regiaoAtuacao || this.regiaoAtuacao.length === 0) {
      next(new Error('Região de atuação é obrigatória para coletores'));
    }
  }
  next();
});

module.exports = mongoose.model('Usuario', usuarioSchema);