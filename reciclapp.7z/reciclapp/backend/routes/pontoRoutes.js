const express = require('express');
const router = express.Router();
const controller = require('../controllers/PontoColetaController');

router.get('/', controller.listar);
router.post('/', controller.adicionar);
router.delete('/:id', controller.remover);

module.exports = router;