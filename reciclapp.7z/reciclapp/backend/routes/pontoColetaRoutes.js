const express = require('express');
const router = express.Router();
const pontoColetaController = require('../controllers/pontoColetaController');

// Rotas básicas de CRUD
router.post('/', pontoColetaController.criar);
router.get('/', pontoColetaController.listar);
router.get('/:id', pontoColetaController.buscarPorId);
router.put('/:id', pontoColetaController.atualizar);
router.patch('/:id/status', pontoColetaController.alterarStatus);

// Rotas de busca específicas
router.get('/proximos', pontoColetaController.buscarProximos);
router.get('/material/:material', pontoColetaController.buscarPorMaterial);
router.get('/zona/:zona', pontoColetaController.buscarPorZona);

module.exports = router;