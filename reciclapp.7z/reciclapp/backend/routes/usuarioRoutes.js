const express = require('express');
const router = express.Router();
const usuarioController = require('../controllers/usuarioController');

// Rotas básicas de CRUD
router.post('/', usuarioController.criar);
router.get('/', usuarioController.listar);
router.get('/:id', usuarioController.buscarPorId);
router.put('/:id', usuarioController.atualizar);
router.delete('/:id', usuarioController.desativar);

// Rotas específicas
router.get('/coletores/zona/:zona', usuarioController.buscarColetoresPorRegiao);
router.get('/empresas/material/:material', usuarioController.buscarEmpresasPorMaterial);

module.exports = router;